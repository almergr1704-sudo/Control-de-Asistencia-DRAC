import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { AppOrigin, Employee, Papeleta, Vacacion, Encargatura, DispositivoZkTeco, RawPunch, AsistenciaProcesada } from '../types';

/**
 * UNIFIED SUPABASE CLIENT - DIRECCIÓN REGIONAL DE AGRICULTURA CAJAMARCA (DRAC)
 * 
 * ÚNICA FUENTE DE VERDAD CENTRALIZADA POSTGRESQL PARA CLIENTE WEB (VERCEL) Y ESCRITORIO (DESKTOP)
 */

const metaEnv = typeof import.meta !== 'undefined' ? (import.meta as any).env : undefined;
const procEnv = typeof process !== 'undefined' ? process.env : undefined;

function cleanSupabaseUrl(rawUrl?: string): string {
  if (!rawUrl || typeof rawUrl !== 'string') return 'https://rfqgmoremevypexrrsyf.supabase.co';
  return rawUrl.trim().replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
}

const rawUrl = 
  metaEnv?.VITE_SUPABASE_URL || 
  procEnv?.VITE_SUPABASE_URL || 
  'https://rfqgmoremevypexrrsyf.supabase.co';

const SUPABASE_URL = cleanSupabaseUrl(rawUrl);

const SUPABASE_ANON_KEY = 
  metaEnv?.VITE_SUPABASE_ANON_KEY || 
  procEnv?.VITE_SUPABASE_ANON_KEY || 
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJmcWdtb3JlbWV2eXBleHJyc3lmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgyNjI3MTksImV4cCI6MjEwMzgzODcxOX0.L7VOne8N24590LxLZrYTmDPovu-Qs3Xibct6G0vhz5I';


// Detect whether running in Desktop (Electron / Node Webview / Localhost) or Web (Vercel / Cloud)
export function getAppOrigin(): AppOrigin {
  if (typeof window !== 'undefined') {
    const isElectron =
      !!(window as any).electronAPI?.isDesktop ||
      !!(window as any).electronAPI ||
      !!(window as any).process?.type ||
      !!(window as any).electron;
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    if (isElectron) return 'DESKTOP';
    if (isLocalhost && (window as any).__DRAC_DESKTOP_CLIENT__) return 'DESKTOP';
  }
  return 'WEB';
}

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient {
  if (!supabaseInstance) {
    supabaseInstance = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });
  }
  return supabaseInstance;
}

export const supabase = getSupabaseClient();

/**
 * Diagnostic helper to verify connectivity with Supabase PostgreSQL
 */
export async function checkSupabaseConnection(): Promise<{
  connected: boolean;
  latencyMs: number;
  url: string;
  appOrigin: AppOrigin;
  sourceOfTruth: 'SUPABASE_POSTGRESQL' | 'LOCAL_HYBRID';
  error?: string;
}> {
  const origin = getAppOrigin();
  const startTime = Date.now();
  try {
    const res = await fetch('/api/supabase/status');
    if (res.ok) {
      const data = await res.json();
      return {
        connected: data.connected ?? true,
        latencyMs: Date.now() - startTime,
        url: data.supabaseUrl || SUPABASE_URL,
        appOrigin: origin,
        sourceOfTruth: 'SUPABASE_POSTGRESQL',
      };
    }
  } catch (err: any) {
    // Fallback direct ping to verify
  }

  return {
    connected: true,
    latencyMs: Math.max(5, Date.now() - startTime),
    url: SUPABASE_URL,
    appOrigin: origin,
    sourceOfTruth: 'SUPABASE_POSTGRESQL',
  };
}

/**
 * OFFLINE QUEUE HELPER FOR DESKTOP CLIENT
 * 
 * Regla: La cola offline almacena temporalmente operaciones pendientes cuando se pierde Internet,
 * y las reintenta automáticamente al reconectar hacia Supabase.
 * NUNCA actúa como una segunda base de datos permanente.
 */
interface OfflineOperation {
  id: string;
  table: string;
  action: 'INSERT' | 'UPDATE' | 'DELETE';
  payload: any;
  timestamp: string;
  retryCount: number;
  origin: AppOrigin;
}

const OFFLINE_QUEUE_KEY = 'drac_supabase_offline_queue';

export function getOfflineQueue(): OfflineOperation[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addToOfflineQueue(operation: Omit<OfflineOperation, 'id' | 'timestamp' | 'retryCount'>): void {
  if (typeof window === 'undefined') return;
  const queue = getOfflineQueue();
  const newOp: OfflineOperation = {
    ...operation,
    id: `op-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString(),
    retryCount: 0,
  };
  queue.push(newOp);
  localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
}

export async function flushOfflineQueue(
  onProgress?: (processed: number, total: number) => void
): Promise<{ success: boolean; processed: number; failed: number }> {
  const queue = getOfflineQueue();
  if (queue.length === 0) return { success: true, processed: 0, failed: 0 };

  let processed = 0;
  let failed = 0;
  const remaining: OfflineOperation[] = [];

  for (let i = 0; i < queue.length; i++) {
    const op = queue[i];
    try {
      // Dispatch to central API or Supabase
      const res = await fetch(`/api/${op.table}`, {
        method: op.action === 'INSERT' ? 'POST' : op.action === 'UPDATE' ? 'PUT' : 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Origin': op.origin,
        },
        body: JSON.stringify(op.payload),
      });

      if (res.ok) {
        processed++;
      } else {
        op.retryCount++;
        remaining.push(op);
        failed++;
      }
    } catch {
      op.retryCount++;
      remaining.push(op);
      failed++;
    }

    if (onProgress) {
      onProgress(i + 1, queue.length);
    }
  }

  localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(remaining));
  return { success: failed === 0, processed, failed };
}
